package org.example;

import java.util.concurrent.CompletableFuture;

public class Main {
    public static void main(String[] args) {
        // Instantiate the repository
        BrawlerRepository brawlerRepository = new BrawlerRepository();

        try {
            // Get the CompletableFuture<ItemResponse> from the repository
            CompletableFuture<ItemResponse> futureResponse = brawlerRepository.getBrawlers();

            // Block and get the ItemResponse using join()
            ItemResponse lista_finale = futureResponse.join();

            // Print the items (assuming ItemResponse has this structure)
            for (Item item : lista_finale.getItems()) {
                System.out.println(item.getName());
            }

            System.out.println("finito");
        } finally {
            // Shutdown the OkHttpClient after use
            brawlerRepository.shutdownClient();
        }
    }
}