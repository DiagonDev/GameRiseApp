package org.example;

import java.util.concurrent.CompletableFuture;

public class BrawlerRemoteDataSource extends AbstractRemoteDataSource {
    protected BrawlerRemoteDataSource(ApiService apiService) {
        super(apiService);
    }

    /**
     * Recupera tutti brawlers dall'API REST.
     *
     * @return Lista di brawlers.
     */
    public CompletableFuture<ItemResponse> getBrawlerListAsync() {
        CompletableFuture<ItemResponse> future = super.makeGETRequest(apiService.getBrawlerList());

        // Handle the response asynchronously
        return future.thenApply(response -> {
            // Process the response and return the result
            return response != null ? response : new ItemResponse();  // Return fallback if needed
        }).exceptionally(e -> {
            // Handle exception and return a fallback response
            e.printStackTrace();
            return new ItemResponse(); // Return fallback on error
        });
    }


}
