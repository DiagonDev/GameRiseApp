package org.example;

import com.google.gson.annotations.SerializedName;
import java.util.List;

// Response class containing only the 'items' array
public class ItemResponse {
    @SerializedName("items")
    private List<Item> items;

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }
}
